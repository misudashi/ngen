#          ____                    _                 __  __   _                     _                 _       _ 
#  _ __    / ___|   ___   _ __     | |__    _   _    |  \/  | (_)  ___   _   _    __| |   __ _   ___  | |__   (_)
# | '_ \  | |  _   / _ \ | '_ \    | '_ \  | | | |   | |\/| | | | / __| | | | |  / _` |  / _` | / __| | '_ \  | |
# | | | | | |_| | |  __/ | | | |   | |_) | | |_| |   | |  | | | | \__ \ | |_| | | (_| | | (_| | \__ \ | | | | | |
# |_| |_|  \____|  \___| |_| |_|   |_.__/   \__, |   |_|  |_| |_| |___/  \__,_|  \__,_|  \__,_| |___/ |_| |_| |_|
#                                           |___/                                                                
#
#    https://discord.gg/tvr3jMFSmt
#
#   ____                     _   _   _               
#  / ___|  _ __    ___    __| | (_) | |_   ___   _   
# | |     | '__|  / _ \  / _` | | | | __| / __| (_)  
# | |___  | |    |  __/ | (_| | | | | |_  \__ \  _   
#  \____| |_|     \___|  \__,_| |_|  \__| |___/ (_)   
#___________________________________________________
#
#  __  __   _                     _                 _       _ 
# |  \/  | (_)  ___   _   _    __| |   __ _   ___  | |__   (_)
# | |\/| | | | / __| | | | |  / _` |  / _` | / __| | '_ \  | |
# | |  | | | | \__ \ | |_| | | (_| | | (_| | \__ \ | | | | | |
# |_|  |_| |_| |___/  \__,_|  \__,_|  \__,_| |___/ |_| |_| |_|
                                                             
                                                    




import random, string

amount = int(input("[x] - ##Nitro Codes Amount: "))
value = 1

x = open('nitro_codes.txt', "r+")
x.truncate(0)


while value <= amount:
    code = "https://discord.gift/" + ('').join(random.choices(string.ascii_letters + string.digits, k=16))
    f = open('nitro_codes.txt', "a+")
    f.write(f'{code}\n')
    f.close()
    print(f'[UNCHECKED] {code}')
    value += 1


input("\nNitro Successfully Generated. \n##Nitro Codes By Misudashi - Codes placed in file nitro_codes.txt\n\nPRESS ENTER TO EXIT")