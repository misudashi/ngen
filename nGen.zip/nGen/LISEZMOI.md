##   ____                                                  _               _     _   _   _                         
##  / ___|   ___    _ __ ___    _ __ ___     ___   _ __   | |_     _   _  | |_  (_) | | (_)  ___    ___   _ __   _ 
## | |      / _ \  | '_ ` _ \  | '_ ` _ \   / _ \ | '_ \  | __|   | | | | | __| | | | | | | / __|  / _ \ | '__| (_)
## | |___  | (_) | | | | | | | | | | | | | |  __/ | | | | | |_    | |_| | | |_  | | | | | | \__ \ |  __/ | |     _ 
##  \____|  \___/  |_| |_| |_| |_| |_| |_|  \___| |_| |_|  \__|    \__,_|  \__| |_| |_| |_| |___/  \___| |_|    (_)


## SUR WINDOWS: 

# Double-click sur démarrer.bat (Soyez sûrs d'avoir Python installé sur votre ordinateur: https://python.org/)



## SUR UN AUTRE SERVICE:

# Ouvrez un terminal dans le dossier nGen et tappez `python main.py`. (Soyez sûrs d'avoir Python installé sur votre ordinateur: https://python.org/)


## APRES GENERATION, LES CODES NITRO IRONT DANS LE FICHIER nitro_codes.txt ! NE SUPPRIMEZ AUCUN FICHIER, CELA POURRAIT ENDOMMAGER LE GENERATEUR.
                                                                                                                 